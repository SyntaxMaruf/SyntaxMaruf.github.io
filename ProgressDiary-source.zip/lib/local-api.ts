import {validateBackup} from './backup-import';
import {validProfile,validEntry,metrics} from './diary';
const key='progressdiary-github-v1';
export async function localApi(path:string,method='GET',data?:any):Promise<any>{
 let db:any;try{const raw=localStorage.getItem(key);db=raw?JSON.parse(raw):{profile:null,entries:[],history:[]};}catch{throw Error('Browser storage is unavailable. Enable storage to use this diary.');}
 const url=new URL(path,'https://local/'),route=url.pathname.slice(1);
 const save=()=>{try{localStorage.setItem(key,JSON.stringify(db));}catch{throw Error('Unable to save: browser storage is full or unavailable. Download a backup before continuing.');}};
 const old=db.entries.find((e:any)=>e.date===(data?.date||data?.entry?.date));
 const snapshot=(e:any,action:string)=>db.history.push({date:e.date,entry:structuredClone(e),revision:e.revision,savedAt:new Date().toISOString(),action});
 if(route==='state')return {profile:db.profile,entries:db.entries.filter((e:any)=>!e.archived)};
 if(route==='backup')return {format:'ProgressDiary browser backup v1',exportedAt:new Date().toISOString(),profile:db.profile,entries:db.entries,history:db.history};
 if(route==='import'&&method==='POST'){
  const backup=validateBackup(data?.backup),existingDates=new Set(db.entries.map((e:any)=>e.date));
  const incoming=backup.entries.filter((e:any)=>!existingDates.has(e.date)),addedDates=new Set(incoming.map((e:any)=>e.date));
  if(!db.profile&&!backup.profile)throw Error('This backup has no profile. Create your profile first.');
  if(backup.profile&&(!db.profile||data.useProfile===true)){const rev=Math.max(db.profile?.revision||0,backup.profile.revision)+1;db.profile={...backup.profile,revision:rev};}
  db.entries.push(...incoming);db.history.push(...backup.history.filter((h:any)=>addedDates.has(h.date)));
  for(const entry of incoming){if(!db.history.some((h:any)=>h.date===entry.date&&h.revision===entry.revision))snapshot(entry,'saved');}
  save();return {added:incoming.length,skipped:backup.entries.length-incoming.length};
 }
 if(route==='profile'&&method==='PUT'){
  if(!validProfile(data.profile))throw Error('Check your profile and targets.');
  if((db.profile?.revision||0)!==data.revision)throw Error('Updated in another tab. Reload before saving.');
  db.profile={...data.profile,start:db.profile?.start||data.profile.start,revision:data.revision+1};save();return {revision:db.profile.revision};
 }
 if(route==='day'&&method==='PUT'){
  if(!validEntry(data.entry))throw Error('Check your daily record.');
  const e=data.entry;if(e.finalized&&(metrics(e).logged<24||e.study===null||!e.wake||!e.bed||e.expense===null||e.prayerEnabled&&e.prayers.some((x:number)=>x<0)))throw Error('Complete all 24 hours and daily essentials before finalizing.');
  if((old?.revision||0)!==data.revision||old?.archived)throw Error('Record changed. Reload before saving.');
  const entry={...data.entry,revision:data.revision+1,archived:false};db.entries=db.entries.filter((e:any)=>e.date!==entry.date);db.entries.push(entry);snapshot(entry,entry.finalized?'finalized':'saved');save();return {entry,revision:entry.revision};
 }
 if(route==='day'&&method==='DELETE'){
  if(!old||old.revision!==data.revision)throw Error('Record changed. Reload before archiving.');old.archived=true;old.revision++;snapshot(old,'archived');save();return {archived:true};
 }
 if(route==='history'&&method==='GET'){
  const date=url.searchParams.get('date');if(!date)return {archived:db.entries.filter((e:any)=>e.archived).map(({date,revision}:any)=>({date,revision}))};
  const entry=db.entries.find((e:any)=>e.date===date),before=Number(url.searchParams.get('before')||2147483647);const all=db.history.filter((h:any)=>h.date===date&&h.revision<before).sort((a:any,b:any)=>b.revision-a.revision),versions=all.slice(0,20);
  return {versions,currentRevision:entry?.revision||0,archived:!!entry?.archived,nextBefore:all.length>20?versions[19].revision:null};
 }
 if(route==='history'&&method==='POST'){
  const version=db.history.find((h:any)=>h.date===data.date&&h.revision===data.version);
  if(!old||old.revision!==data.revision||!version)throw Error('Record changed or version missing. Reload history.');
  const entry={...version.entry,revision:old.revision+1,archived:false,finalized:false};db.entries=db.entries.filter((e:any)=>e.date!==entry.date);db.entries.push(entry);snapshot(entry,'restored');save();return {entry,revision:entry.revision};
 }
 throw Error('This action is unavailable.');
}
