import {validProfile,validEntry,validDate} from './diary';
const revision=(v:unknown)=>Number.isSafeInteger(v)&&Number(v)>0&&Number(v)<2147483647;
export function validateBackup(input:any){
 if(!input||!['ProgressDiary backup v3','ProgressDiary browser backup v1'].includes(input.format)||!Array.isArray(input.entries)||!Array.isArray(input.history)||input.entries.length>10000||input.history.length>30000)throw Error('Choose a complete ProgressDiary JSON backup (v3 or browser v1).');
 const profile=input.profile;if(profile!==null&&(!profile||!validProfile(profile)||!revision(profile.revision)))throw Error('The backup profile or routine is invalid. Nothing was imported.');
 const dates=new Set<string>();
 const entries=input.entries.map((e:any)=>{if(!e||!validEntry(e)||!revision(e.revision)||typeof e.archived!=='boolean'||dates.has(e.date))throw Error('The backup has invalid or duplicate daily records. Nothing was imported.');dates.add(e.date);return structuredClone(e);});
 const versions=new Set<string>();const history=input.history.map((h:any)=>{const id=h?.date+':'+h?.revision;if(!h||!validDate(h.date)||!validEntry(h.entry)||h.entry.date!==h.date||!revision(h.revision)||!dates.has(h.date)||versions.has(id)||!['saved','finalized','archived','restored','legacy'].includes(h.action)||h.savedAt!==null&&(typeof h.savedAt!=='string'||!Number.isFinite(Date.parse(h.savedAt))))throw Error('The backup version history is invalid. Nothing was imported.');versions.add(id);return {date:h.date,entry:structuredClone(h.entry),revision:h.revision,savedAt:h.savedAt,action:h.action};});
 return {profile:profile?structuredClone(profile):null,entries,history};
}
